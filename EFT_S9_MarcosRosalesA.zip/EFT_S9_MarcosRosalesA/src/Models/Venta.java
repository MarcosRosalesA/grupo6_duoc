/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.time.LocalDateTime;

/**
 *
 * @author M
 */
public class Venta {
    private Cliente cliente;
    private Equipo equipo;
    private double total;
    private LocalDateTime fechayhora;

    public Venta(Cliente cliente, Equipo equipo, double total, LocalDateTime fechayhora) {
        this.cliente = cliente;
        this.equipo = equipo;
        this.total = equipo.getPrecio();
        this.fechayhora = LocalDateTime.now();
    }

    public LocalDateTime getFechayhora() {
        return fechayhora;
    }

    public void setFechayhora(LocalDateTime fechayhora) {
        this.fechayhora = fechayhora;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

  
  
    
    
}
