/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;

import Models.Desktop;
import Models.Equipo;
import Models.Laptop;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author M
 */
public class ControllerEquipo {
    private List<Equipo> equipos;
    private DatabaseConnection db;

    public ControllerEquipo() {
        equipos = new ArrayList<>();
        db = DatabaseConnection.getInstance();       
    }
    
   public List<Equipo> getDesktopFromDB(){
        List<Equipo> equipos = new ArrayList<>();
        String query = "SELECT * FROM DESKTOP";
        try{
            Connection connection = db.getConnection();
            if (!connection.isClosed()) {
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query);
                
                while (resultSet.next()){
                    String modelo = resultSet.getString("modelo");
                    String cpu = resultSet.getString("cpu");
                    int disco = resultSet.getInt("disco");
                    int ram = resultSet.getInt("ram");
                    double precio = resultSet.getDouble("precio");
                    boolean disponible = resultSet.getBoolean("disponible");
                    String fuente = resultSet.getString("fuente");
                    String forma = resultSet.getString("forma");
                    Equipo equipo = new Desktop(modelo,cpu,disco,ram,precio,disponible,fuente,forma);
                    equipos.add(equipo);
                }
            }
        }    
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener los clientes de las base de datos" + e.getMessage());
        }   
        return equipos;
    }
   
      public List<Equipo> getLaptopFromDB(){
        List<Equipo> equipos = new ArrayList<>();
        String query = "SELECT * FROM LAPTOP";
        try{
            Connection connection = db.getConnection();
            if (!connection.isClosed()) {
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query);
                
                while (resultSet.next()){
                    String modelo = resultSet.getString("modelo");
                    String cpu = resultSet.getString("cpu");
                    int disco = resultSet.getInt("disco");
                    int ram = resultSet.getInt("ram");
                    double precio = resultSet.getDouble("precio");
                    boolean disponible = resultSet.getBoolean("disponible");
                    String fuente = resultSet.getString("pulgadas");
                    String forma = resultSet.getString("puertos");
                    boolean touch = resultSet.getBoolean("touch");
                    Equipo equipo = new Laptop(modelo,cpu,disco,ram,precio,disponible,fuente,forma,touch);
                    equipos.add(equipo);
                }
            }
        }    
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener los clientes de las base de datos" + e.getMessage());
        }   
        return equipos;
    }
      
      
        public void insertarDesktop(Desktop desktop) throws SQLException{
        String sql = "insert into desktop(modelo, cpu, disco, ram, precio, disponible, fuente, forma) values (?,?,?,?,?,?,?,?)";
        Connection connection = db.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setString(1, desktop.getModelo());
            statement.setString(2, desktop.getCpu());
            statement.setInt(3, desktop.getDisco());
            statement.setInt(4,desktop.getRam());
            statement.setDouble(5, desktop.getPrecio());
            statement.setBoolean(6, desktop.isDisponible());
            statement.setString(7, desktop.getFuente());
            statement.setString(8, desktop.getForma());
            statement.executeUpdate();
            System.out.println("Desktop Ingresado con éxito");
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener los clientes de las base de datos" + e.getMessage());
        }   
    }   
        public void insertarLaptop(Laptop laptop) throws SQLException{
        String sql = "insert into laptop(modelo, cpu, disco, ram, precio, disponible, pulgadas, puertos, touch) values (?,?,?,?,?,?,?,?,?)";
        Connection connection = db.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setString(1, laptop.getModelo());
            statement.setString(2, laptop.getCpu());
            statement.setInt(3, laptop.getDisco());
            statement.setInt(4,laptop.getRam());
            statement.setDouble(5, laptop.getPrecio());
            statement.setBoolean(6, laptop.isDisponible());
            statement.setString(7, laptop.getPulgadas());
            statement.setString(8, laptop.getPuertos());
            statement.setBoolean(9, laptop.isTouch());
            statement.executeUpdate();
            System.out.println("Laptop Ingresado con éxito");
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener los clientes de las base de datos" + e.getMessage());
        }   
    }
        
    

        public Laptop buscarLaptop(String modelo) {
        String sql = "SELECT * FROM LAPTOP WHERE modelo = ?";
        try (Connection connection = db.getConnection()) {
            if (connection == null || connection.isClosed()) {
                System.out.println("La conexión está cerrada o es nula.");
                return null;
            }else{
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, modelo);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    String nModelo = resultSet.getString("modelo");
                    String cpu = resultSet.getString("cpu");
                    int disco = resultSet.getInt("disco");
                    int ram = resultSet.getInt("ram");
                    double precio = resultSet.getDouble("precio");
                    boolean disponible = resultSet.getBoolean("disponible");
                    String pulgadas = resultSet.getString("pulgadas") ;
                    String puertos = resultSet.getString("puertos");
                    Boolean touch = resultSet.getBoolean("touch");
                   return new Laptop(nModelo,cpu,disco,ram,precio,disponible,pulgadas,puertos,touch);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Error al ejecutar la consulta: " + e.getMessage());
            }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al obtener la conexión: " + e.getMessage());
        }
       return null;
    }
    
      public Desktop buscarDesktop(String modelo) {
        String sql = "SELECT * FROM DESKTOP WHERE modelo = ?";
        try (Connection connection = db.getConnection()) {
            if (connection == null || connection.isClosed()) {
                System.out.println("La conexión está cerrada o es nula.");
                return null;
            }else{
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, modelo);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    String nModelo = resultSet.getString("modelo");
                    String cpu = resultSet.getString("cpu");
                    int disco = resultSet.getInt("disco");
                    int ram = resultSet.getInt("ram");
                    double precio = resultSet.getDouble("precio");
                    boolean disponible = resultSet.getBoolean("disponible");
                    String fuente = resultSet.getString("fuente") ;
                    String forma = resultSet.getString("forma");
                   return new Desktop(nModelo,cpu,disco,ram,precio,disponible,fuente,forma);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Error al ejecutar la consulta: " + e.getMessage());
            }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al obtener la conexión: " + e.getMessage());
        }
       return null;
    }
    
      
    
}
