/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author M
 */
public class Desktop extends Equipo {
    private String fuente;
    private String forma;

    public Desktop(String modelo, String cpu, int disco, int ram, double precio, boolean disponible, String fuente, String forma) {
        super(modelo, cpu, disco, ram, precio, disponible);
        this.fuente = fuente;
        this.forma = forma;
    }

    public String getFuente() {
        return fuente;
    }

    public void setFuente(String fuente) {
        this.fuente = fuente;
    }

    public String getForma() {
        return forma;
    }

    public void setForma(String forma) {
        this.forma = forma;
    }
    
    
}
