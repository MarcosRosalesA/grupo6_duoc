/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author M
 */
public class DatabaseConnection {
    private static DatabaseConnection instancia = null;
    
    private static final String URL = "jdbc:mysql://localhost:3306/computec";
    private static final String USER = "root";
    private static final String PASS = "";   
    private Connection connection;
    
    public DatabaseConnection(){
        conectar();
    }
    
    public static DatabaseConnection getInstance(){
        if(instancia == null){
            instancia = new DatabaseConnection();
        }
        return instancia;
    }
    
    
    private void conectar(){
        try{
            connection = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("Conexión establecida con éxito");
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al establecer a conexión con la BD: " +e.getMessage());
        }
    }
    
    public Connection getConnection(){
        return connection;
    }
    
    public void desconectar(){
        if(connection != null){
            try{
                connection.close();
                System.out.println("Conexión cerrada con éxito");
            }
            catch(SQLException e){
                e.printStackTrace();
                System.out.println("Error al cerrar la conexion con la BD: "+e.getMessage());
            }
        
        }
    }
}
