/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;

import Models.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author M
 */
public class ControllerCliente {
    private List<Cliente> clientes;
    private DatabaseConnection db;

    public ControllerCliente() {
        clientes = new ArrayList<>();
        db = DatabaseConnection.getInstance();       
    }
    
   public List<Cliente> getClientesFromDB(){
        List<Cliente> clientes = new ArrayList<>();
        String query = "SELECT * FROM CLIENTE";
        try{
            Connection connection = db.getConnection();
            if (!connection.isClosed()) {
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query);
                
                while (resultSet.next()){
                    int rut = resultSet.getInt("rut");
                    String nombres = resultSet.getString("nombres");
                    String apellidos = resultSet.getString("apellidos");
                    String direccion = resultSet.getString("direccion");
                    String comuna = resultSet.getString("comuna");
                    String correo = resultSet.getString("correo");
                    int numero = resultSet.getInt("numero");
                    Cliente cliente = new Cliente(rut,nombres,apellidos,direccion,comuna,correo,numero);
                    clientes.add(cliente);
                }
            }
        }    
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener los clientes de las base de datos" + e.getMessage());
        }   
        return clientes;
    }
   
        public void insertarCliente(Cliente cliente) throws SQLException{
        String sql = "insert into cliente(rut, nombres, apellidos, direccion, comuna, correo, numero) values (?,?,?,?,?,?,?)";
        Connection connection = db.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setInt(1, cliente.getRut());
            statement.setString(2, cliente.getNombres());
            statement.setString(3, cliente.getApellidos());
            statement.setString(4,cliente.getDireccion());
            statement.setString(5, cliente.getComuna());
            statement.setString(6, cliente.getCorreo());
            statement.setInt(7, cliente.getNumero());
            statement.executeUpdate();
            System.out.println("Cliente Ingresado con éxito");
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener los clientes de las base de datos" + e.getMessage());
        }   
    }
    
    public boolean eliminarCliente(int rut) throws SQLException{

        String sql = "DELETE FROM CLIENTE WHERE rut = (?)";
        Connection connection = db.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        try{
            statement.setInt(1, rut);
            statement.executeUpdate();
            System.out.println("Cliente eliminado con éxito");
            return true;
        }
        catch(SQLException e){
            e.printStackTrace();
            System.out.println("Error al obtener los clientes de las base de datos" + e.getMessage());
        }   
        return false;
    }
    
    
    public Cliente buscarClienteporRut(int rut) {
        String sql = "SELECT * FROM CLIENTE WHERE rut = ?";
        try (Connection connection = db.getConnection()) {
            if (connection == null || connection.isClosed()) {
                System.out.println("La conexión está cerrada o es nula.");
                return null;
            }else{
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, rut);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    int Crut = resultSet.getInt("rut");
                    String nombres = resultSet.getString("nombres");
                    String apellidos = resultSet.getString("apellidos");
                    String direccion = resultSet.getString("direccion");
                    String comuna = resultSet.getString("comuna");
                    String correo = resultSet.getString("correo");
                    int numero = resultSet.getInt("numero");
                    
                    return new Cliente(Crut, nombres, apellidos, direccion, comuna, correo, numero);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Error al ejecutar la consulta: " + e.getMessage());
            }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error al obtener la conexión: " + e.getMessage());
        }
       return null;
    }
        
}
