/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author M
 */
public class Laptop extends Equipo {
    private String pulgadas;
    private String puertos;
    private boolean touch;

    public Laptop(String modelo, String cpu, int disco, int ram, double precio, boolean disponible, String pulgadas, String puertos, boolean touch) {
        super(modelo, cpu, disco, ram, precio, disponible);
        this.pulgadas = pulgadas;
        this.puertos = puertos;
        this.touch = touch;
    }

    public String getPulgadas() {
        return pulgadas;
    }

    public void setPulgadas(String pulgadas) {
        this.pulgadas = pulgadas;
    }

    public String getPuertos() {
        return puertos;
    }

    public void setPuertos(String puertos) {
        this.puertos = puertos;
    }

    public boolean isTouch() {
        return touch;
    }

    public void setTouch(boolean touch) {
        this.touch = touch;
    }


    
    
}
