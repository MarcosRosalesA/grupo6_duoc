/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controllers;
import Models.Cliente;
import Models.Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
/**
 *
 * @author M
 */
public class ControllerVentas {
    private DatabaseConnection db;
    private List<Venta> ventas;
    
    public ControllerVentas(){
        db = DatabaseConnection.getInstance();
    }
        
    
    
    
    public int obtenerIdClientePorRut(String rut) {
         Connection connection = db.getConnection();
        String sql = "SELECT id FROM cliente WHERE rut = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, rut);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Si no se encuentra, retorna -1
    }
    
    public int obtenerIdDeskPorModelo(String modelo) {
         Connection connection = db.getConnection();
        String sql = "SELECT id FROM desktop WHERE modelo = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, modelo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Si no se encuentra, retorna -1
    }
    
        public boolean agregarVentaDesk(String rutCliente, String modeloEquipo) {
             Connection connection = db.getConnection();
        // Obtener IDs de cliente y equipo
        int idCliente = obtenerIdClientePorRut(rutCliente);
        int idEquipo = obtenerIdDeskPorModelo(modeloEquipo);

        if (idCliente == -1 || idEquipo == -1) {
            System.out.println("Error: No se encontró el cliente o el equipo.");
            return false;
        }
        double precio = obtenerPrecioEquipo(idEquipo);

        // Insertar la venta
        String sql = "INSERT INTO ventasdesk (idCliente, idDesk, total, fechaHora) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idCliente);
            stmt.setInt(2, idEquipo);
            stmt.setDouble(3, precio);
            stmt.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
            stmt.executeUpdate();
            System.out.println("Venta agregada con éxito.");
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return true;
        
        }
        
        
        private double obtenerPrecioEquipo(int idEquipo) {
            Connection connection = db.getConnection();
        String sql = "SELECT precio FROM desktop WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idEquipo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("precio");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0; // Si no se encuentra el equipo, retornar 0
    }
        
        public boolean agregarVentaLap(String rutCliente, String modeloEquipo) {
             Connection connection = db.getConnection();
        // Obtener IDs de cliente y equipo
        int idCliente = obtenerIdClientePorRut(rutCliente);
        int idEquipo = obtenerIdLapPorModelo(modeloEquipo);

        if (idCliente == -1 || idEquipo == -1) {
            System.out.println("Error: No se encontró el cliente o el equipo.");
            return false;
        }
        double precio = obtenerPrecioEquipoLap(idEquipo);

        // Insertar la venta
        String sql = "INSERT INTO ventaslaptop (idCliente, idLap, total, fechaHora) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idCliente);
            stmt.setInt(2, idEquipo);
            stmt.setDouble(3, precio);
            stmt.setTimestamp(4, Timestamp.valueOf(LocalDateTime.now()));
            stmt.executeUpdate();
            System.out.println("Venta agregada con éxito.");
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return true;
        
        }
        
        
        private double obtenerPrecioEquipoLap(int idEquipo) {
            Connection connection = db.getConnection();
        String sql = "SELECT precio FROM laptop WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idEquipo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("precio");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0; // Si no se encuentra el equipo, retornar 0
    }
        
        public int obtenerIdLapPorModelo(String modelo) {
         Connection connection = db.getConnection();
        String sql = "SELECT id FROM laptop WHERE modelo = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, modelo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Si no se encuentra, retorna -1
    }
}
  


